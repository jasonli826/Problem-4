﻿using consumer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace consumer.Repository
{
   public interface IBPIRepository
    {
        void InsertBPI(BPI bpi);
    }
}
