﻿using consumer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace consumer.Repository
{
    public class BPIRepository : IBPIRepository
    {

        private readonly BPIContext _dbContext;
        public BPIRepository(BPIContext dbContext)
        {
            _dbContext = dbContext;
        }
        public void InsertBPI(BPI bpi)
        {
            _dbContext.BPI.Add(bpi);
        }
    }
}
