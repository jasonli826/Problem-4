﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace consumer.Models
{
    public class BPIContext: DbContext
    {
       public BPIContext(DbContextOptions<BPIContext> options)
     : base(options)
        {
        }

        public DbSet<BPI> BPI { get; set; } = null!;
    }
}
