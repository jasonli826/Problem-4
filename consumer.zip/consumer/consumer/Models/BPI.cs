﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace consumer.Models
{
    public class BPI
    {
        [Key]
        public int Id { get; set; }
        public DateTime UpdatedTime { get; set; }
        public string chartName { get; set; }

        public string USD_RATE { get; set; }

        public double USD_RATE_FLOAT { get; set; }

    }
}